package oop2324de2.vector;

import java.util.ArrayList;
import java.util.List;

public class MyListVector extends AbstractMyVector {
    private List<Double> data;

    /**
     * Khởi tạo mặc định cho vector.
     */
    public MyListVector() {
        /* TODO */
        data = new ArrayList<Double>();
    }

    @Override
    public int size() {
        /* TODO */
        return data.size();
    }

    @Override
    public double coordinate(int index) {
        /* TODO */
        return data.get(index);
    }

    @Override
    public double[] coordinates() {
        /* TODO */
        double [] coordinates = new double[size()];
        for (int i = 0; i < size(); i++) {
            coordinates[i] = data.get(i);
        }
        return coordinates;
    }

    @Override
    public void set(double value, int index) {
        /* TODO */
        data.set(index, value);
    }

    /**
     * Cộng các phần tử của vector với value.
     * @param value
     * @return vector mới.
     */
    public MyListVector add(double value) {
        /* TODO */
        MyListVector add = new MyListVector();
        for (int i = 0; i < data.size(); i++) {
            add.set(data.get(i) + value, i);
        }
        return add;
    }

    /**
     * Cộng vector hiện tại với một vector khác.
     * Nếu hai vector không cùng số chiều thì không cộng được.
     * In ra thông báo lỗi hoặc ném exception.
     * @param another
     * @return vector mới.
     */
    public MyListVector add(MyVector another) {
        /* TODO */
        if (another.size() != size()) {
            throw new IllegalArgumentException();
        }
        for (int i = 0; i < another.size(); i++) {
            data.set(i, data.get(i) + another.coordinate(i));
        }
        return this;
    }

    /**
     * Cộng các phần tử của vector với value.
     * @param value
     * @return vector hiện tại.
     */
    public MyListVector addTo(double value) {
        /* TODO */
        for (int i = 0; i < data.size(); i++) {
            data.set(i, data.get(i) + value);
        }
        return this;
    }

    /**
     * Cộng vector hiện tại với một vector khác.
     * Nếu hai vector không cùng số chiều thì không cộng được.
     * In ra thông báo lỗi hoặc ném exception.
     * @param another
     * @return vector hiện tại.
     */
    public MyListVector addTo(MyVector another) {
        /* TODO */
        if (another.size() != size()) {
            throw new IllegalArgumentException();
        }
        for (int i = 0; i < another.size(); i++) {
            data.set(i, data.get(i) + another.coordinate(i));
        }
        return this;
    }

    /**
     * Trừ các phần tử của vector cho value.
     * @return vector mới.
     */
    public MyListVector minus(double value) {
        /* TODO */
        MyListVector minus = new MyListVector();
        for (int i = 0; i < data.size(); i++) {
            minus.set(data.get(i) - value, i);
        }
        return minus;
    }

    /**
     * Trừ vector hiện tại cho vector khác.
     * Nếu hai vector không cùng số chiều thì không trừ được.
     * In ra thông báo lỗi hoặc ném exception.
     * @return vector mới.
     */
    public MyListVector minus(MyVector another) {
        /* TODO */
        if (another.size() != size()) {
            throw new IllegalArgumentException();
        }
        MyListVector minus = new MyListVector();
        for (int i = 0; i < another.size(); i++) {
            minus.set(data.get(i) - (another.coordinate(i)), i);
        }
        return minus;
    }

    /**
     * Trừ các phần tử của vector cho value.
     * @return vector hiện tại.
     */
    public MyListVector minusFrom(double value) {
        /* TODO */
        for (int i = 0; i < data.size(); i++) {
            data.set(i,data.get(i) -value);
        }
        return this;
    }

    /**
     * Trừ vector hiện tại cho vector khác.
     * Nếu hai vector không cùng số chiều thì không trừ được.
     * In ra thông báo lỗi hoặc ném exception.
     * @return vector hiện tại.
     */
    public MyListVector minusFrom(MyVector another) {
        /* TODO */
        if (another.size() != size()) {
            throw new IllegalArgumentException();
        }
        for (int i = 0; i < another.size(); i++) {
            data.set(i,data.get(i) -another.coordinate(i));
        }
        return this;
    }

    /**
     * Tích vô hướng của hai vector.
     * Hai vector chỉ có tích vô hướng nếu có cùng số chiều.
     * Nếu hai vector không cùng số chiều, in ra thông báo lỗi hoặc ném exception.
     * @return tích vô hướng.
     */
    public double dot(MyVector another) {
        /* TODO */
        if (another.size() != size()) {
            throw new IllegalArgumentException();
        }
        double dot = 0;
        for (int i = 0; i < another.size(); i++) {
            dot += data.get(i) * another.coordinate(i);
        }
        return dot;
    }

    /**
     * Các phần tử vector được lấy mũ power.
     * @param power
     * @return vector hiện tại.
     */
    public MyListVector pow(double power) {
        /* TODO */
        for (int i = 0; i < data.size(); i++) {
            double tmp = 1.0;
            for (int j = 1; j < power; j++) {
                tmp *= data.get(i);
            }
            data.set(i, tmp);
        }
        return this;
    }

    /**
     * Các phần tử vector được nhân với value.
     * @return vector hiện tại.
     */
    public MyListVector scale(double value) {
        /* TODO */
        for (int i = 0; i < data.size(); i++) {
            data.set(i, data.get(i) * value);
        }
        return this;
    }

    /**
     * Lấy chuẩn của vector.
     * @return chuẩn của vector.
     */
    @Override
    public double norm() {
        /* TODO */
        double norm = 0;
        for (int i = 0; i < data.size(); i++) {
            norm += data.get(i) * data.get(i);
        }
        return Math.sqrt(norm);
    }

    /**
     * Thêm một giá trị value vào vector ở vị trí cuối cùng.
     * @param value
     * @return vector hiện tại.
     */
    public MyListVector insert(double value) {
        /* TODO */
        data.add(value);
        return this;
    }

    /**
     * Thêm một giá trị vào vector ở vị trí index.
     * @param value
     * @param index
     * @return vector hiện tại.
     */
    public MyListVector insert(double value, int index) {
        /* TODO */
        data.add(index, value);
        return this;
    }

    /**
     * Xóa phần tử ở vị trí index.
     * Nếu index không hợp lệ thì in ra thông báo lỗi hoặc ném exception.
     * @param index
     * @return vector hiện tại.
     */
    public MyListVector remove(int index) {
        /* TODO */
        if (index < 0 || index >= size()) {
            throw new IndexOutOfBoundsException();
        }
        data.remove(index);
        return this;
    }

    /**
     * Trích xuất ra một vector con của vector ban đầu, có các phần tử
     * được lấy theo các chỉ số của mảng đầu vào.
     * Ví dụ, cho vector [1 2 3 4 5], cho mảng đầu vào là {2, 1} thì vector trích xuất ra
     * có tọa độ là [2 1].
     * Nếu có thỉ số trong mảng đầu vào không hợp lệ thì in ra thông báo lỗi,
     * hoặc ném exception.
     * @param indices
     * @return vector mới có kiểu MyListVector có các phần tử được trích xuất từ vector hiện tại.
     */
    public MyListVector extract(int[] indices) {
        /* TODO */
        for (int i = 0; i < indices.length; i++) {
            if (indices[i] < 0 || indices[i] >= size()) {
                throw new IllegalArgumentException();
            }
        }
        MyListVector extract = new MyListVector();
        int count = 0;
        for (int i = 0; i < indices.length; i++) {
            for (int j = 0; j < data.size(); j++) {
                if (indices[i] == j) {
                    extract.data.set(count, data.get(j));
                    count++;
                }
            }
        }
        return extract;

    }
}
