package oop2324de2.vector;

import java.util.Random;
import java.util.Vector;

public class TestVector {
    public static void main(String[] args) {
        /*
         TODO

         Thực hiện các yêu cầu sau.

         I. Test chức năng vector
           - Sinh ngẫu nhiên một số tự nhiên, lưu giá trị sinh ra vào biến n.
           - Tạo ra các vector có kích thước n, với các phần tử được sinh ngẫu nhiên. Trong đó có 2 vector kiểu MyArrayList
             và 2 vector có kiểu MyListVector.
           - Viết các hàm để test các chứ năng của các vector, như thêm vào phần tử, xóa bớt phần tử, sửa giá trị các
             phần tử, cộng các vector, nhân vector với vô hướng, tích vô hướng 2 vector, chuẩn vector, ... Mỗi lần thay
             đổi vector hoặc tính toán, in kết quả ra terminal.

         II. Lưu các kết quả chạy chương trình vào file text có tên <Ten_MaSinhVien_Vector>.txt
              (ví dụ NguyenVanA_123456_Vector.txt). Nén các file source code và file kết quả vào file zip có tên
              <Ten_MaSinhVien_Vector>.zip (ví dụ NguyenVanA_123456_Vector.zip), nộp lên classroom.
         */

        Random rand = new Random();
        int n = rand.nextInt(10);
        MyVector vecto1 = new MyArrayVector();
        MyVector vecto2 = new MyArrayVector();
        MyVector vecto3 = new MyListVector();
        MyVector vecto4 = new MyListVector();
        for (int i = 0; i < n; i++) {
            vecto1.insert(rand.nextDouble(10));
            vecto2.insert(rand.nextDouble(10));
            vecto3.insert(rand.nextDouble(10));
            vecto4.insert(rand.nextDouble(10));
        }
        System.out.println("Vecto 1 : ");
        System.out.println(vecto1);
        System.out.println("Vecto 2 : ");
        System.out.println(vecto2);
        System.out.println("Vecto 3 : ");
        System.out.println(vecto3);
        System.out.println("Vecto 4 : ");
        System.out.println(vecto4);

        System.out.println("Test vecto 1 after insert :");
        vecto1.insert(1.29);
        System.out.println(vecto1);
        System.out.println("Test vecto 2 after insert :");
        vecto2.insert(1.53, 1);
        System.out.println(vecto2);
        System.out.println("Test vecto 3 after remove :");
        vecto3.remove(2);
        System.out.println(vecto3);
        System.out.println("Test vecto 4 after set :");
        vecto4.set(4.23,3);
        System.out.println(vecto4);

        System.out.println("Test vecto 1 add vecto 2 :");
        vecto1.add(vecto2);
        System.out.println(vecto1);

        System.out.println("Test vecto 2 minus vecto 4 :");
        vecto2.minus(vecto4);
        System.out.println(vecto2);




    }
}
