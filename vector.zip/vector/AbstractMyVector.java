package oop2324de2.vector;

public abstract class AbstractMyVector implements MyVector {
    /**
     * Mô tả vector theo định dạng [a1 a2 ... an]
     * @return
     */
    @Override
    public String toString() {
        /* TODO */
        StringBuilder builder = new StringBuilder();
        builder.append("[");
        for (int i = 0; i < this.size(); i++) {
            builder.append(String.format("%.2f",coordinate(i)));
            if (i < this.size() - 1)
            {
                builder.append(" ");
            }
        }
        builder.append("]");
        return builder.toString();
    }

    /**
     * So sánh hai vector có bằng nhau không.
     * Hai vector bằng nhau nếu có cùng số chiều và có các phần tử bằng nhau.
     * @param another
     * @return
     */
    @Override
    public boolean equals(MyVector another) {
        /* TODO */
        if (another.size() != this.size())
        {
            return false;
        }
        for (int i = 0; i < this.size(); i++) {
            if (this.coordinate(i) != another.coordinate(i))
            {
                return false;
            }
        }
        return true;
    }
}
